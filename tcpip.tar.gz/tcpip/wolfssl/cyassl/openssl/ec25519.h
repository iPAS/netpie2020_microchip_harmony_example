/* ec25519.h  */

#include <wolfssl/openssl/ec25519.h>
